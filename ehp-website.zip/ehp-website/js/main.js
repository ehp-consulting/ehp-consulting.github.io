/* ============================================================
   EHP — Environmental & Hospitality Partners
   Main JavaScript · v1.0
   ============================================================ */

(function () {
  'use strict';

  /* ─── DOM Ready ─── */
  document.addEventListener('DOMContentLoaded', init);

  function init() {
    initNav();
    initHero();
    initReveal();
    initServicesTabs();
    initForm();
    initScrollTop();
    initCounters();
  }

  /* ─────────────────────────────────────────
     NAVIGATION
  ───────────────────────────────────────── */
  function initNav() {
    const nav     = document.getElementById('main-nav');
    const burger  = document.getElementById('nav-burger');
    const mobileMenu = document.getElementById('nav-mobile');
    const overlay = document.getElementById('nav-overlay');
    const mobileLinks = document.querySelectorAll('.nav__mobile-link');

    /* Scroll: add .scrolled class */
    function handleScroll() {
      if (window.scrollY > 60) {
        nav.classList.add('scrolled');
      } else {
        nav.classList.remove('scrolled');
      }
    }
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // run once on load

    /* Mobile menu open/close */
    function openMenu() {
      mobileMenu.classList.add('open');
      overlay.classList.add('open');
      burger.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
    function closeMenu() {
      mobileMenu.classList.remove('open');
      overlay.classList.remove('open');
      burger.classList.remove('open');
      document.body.style.overflow = '';
    }

    burger.addEventListener('click', () => {
      mobileMenu.classList.contains('open') ? closeMenu() : openMenu();
    });
    overlay.addEventListener('click', closeMenu);
    mobileLinks.forEach(link => link.addEventListener('click', closeMenu));

    /* Smooth scroll for all anchor links */
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        const target = document.querySelector(this.getAttribute('href'));
        if (!target) return;
        e.preventDefault();
        closeMenu();
        const offset = nav.offsetHeight + 20;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      });
    });
  }

  /* ─────────────────────────────────────────
     HERO BACKGROUND
  ───────────────────────────────────────── */
  function initHero() {
    const bg = document.querySelector('.hero__bg');
    if (!bg) return;

    // Trigger the loaded class after a brief moment for the parallax intro
    setTimeout(() => bg.classList.add('loaded'), 200);

    // Subtle parallax on scroll
    window.addEventListener('scroll', () => {
      const scrolled = window.scrollY;
      if (scrolled < window.innerHeight) {
        bg.style.transform = `scale(1) translateY(${scrolled * 0.25}px)`;
      }
    }, { passive: true });
  }

  /* ─────────────────────────────────────────
     SCROLL REVEAL  (IntersectionObserver)
  ───────────────────────────────────────── */
  function initReveal() {
    const elements = document.querySelectorAll('.reveal');
    if (!elements.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target); // animate only once
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -60px 0px' }
    );

    elements.forEach(el => observer.observe(el));
  }

  /* ─────────────────────────────────────────
     SERVICES TABS
  ───────────────────────────────────────── */
  function initServicesTabs() {
    const tabBtns  = document.querySelectorAll('.services__tab-btn');
    const panels   = document.querySelectorAll('.services__panel');

    if (!tabBtns.length) return;

    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        // Remove active from all
        tabBtns.forEach(b => b.classList.remove('active'));
        panels.forEach(p => p.classList.remove('active'));

        // Activate clicked
        btn.classList.add('active');
        const targetPanel = document.getElementById(btn.dataset.panel);
        if (targetPanel) {
          targetPanel.classList.add('active');

          // Re-trigger reveal inside newly visible panel
          targetPanel.querySelectorAll('.reveal').forEach(el => {
            el.classList.remove('visible');
            setTimeout(() => el.classList.add('visible'), 50);
          });
        }
      });
    });
  }

  /* ─────────────────────────────────────────
     CONTACT FORM VALIDATION
  ───────────────────────────────────────── */
  function initForm() {
    const form = document.getElementById('contact-form');
    if (!form) return;

    form.addEventListener('submit', handleSubmit);

    /* Real-time validation feedback */
    form.querySelectorAll('[required]').forEach(field => {
      field.addEventListener('blur', () => validateField(field));
      field.addEventListener('input', () => {
        if (field.value.trim()) hideError(field);
      });
    });
  }

  function handleSubmit(e) {
    e.preventDefault();
    const form = e.target;
    let isValid = true;

    /* Validate all required fields */
    form.querySelectorAll('[required]').forEach(field => {
      if (!validateField(field)) isValid = false;
    });

    if (!isValid) return;

    /* Simulate form submission (replace with real endpoint) */
    const btn = form.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.textContent = 'Enviando…';
    btn.disabled = true;

    setTimeout(() => {
      form.style.display = 'none';
      const success = document.getElementById('form-success');
      if (success) success.style.display = 'block';
      btn.textContent = originalText;
      btn.disabled = false;
    }, 1800);
  }

  function validateField(field) {
    const value = field.value.trim();
    let valid = true;
    let message = '';

    if (!value) {
      valid = false;
      message = 'Este campo es obligatorio';
    } else if (field.type === 'email') {
      const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRe.test(value)) {
        valid = false;
        message = 'Por favor introduzca un correo válido';
      }
    }

    if (!valid) {
      showError(field, message);
    } else {
      hideError(field);
    }
    return valid;
  }

  function showError(field, message) {
    field.style.borderColor = '#e07878';
    let errorEl = field.parentNode.querySelector('.form__error');
    if (!errorEl) {
      errorEl = document.createElement('span');
      errorEl.className = 'form__error';
      field.parentNode.appendChild(errorEl);
    }
    errorEl.textContent = message;
    errorEl.style.display = 'block';
  }

  function hideError(field) {
    field.style.borderColor = '';
    const errorEl = field.parentNode.querySelector('.form__error');
    if (errorEl) errorEl.style.display = 'none';
  }

  /* ─────────────────────────────────────────
     SCROLL-TO-TOP BUTTON
  ───────────────────────────────────────── */
  function initScrollTop() {
    const btn = document.getElementById('scroll-top');
    if (!btn) return;

    window.addEventListener('scroll', () => {
      if (window.scrollY > 600) {
        btn.classList.add('show');
      } else {
        btn.classList.remove('show');
      }
    }, { passive: true });

    btn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ─────────────────────────────────────────
     ANIMATED COUNTERS
  ───────────────────────────────────────── */
  function initCounters() {
    const counters = document.querySelectorAll('[data-counter]');
    if (!counters.length) return;

    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.5 }
    );

    counters.forEach(c => observer.observe(c));
  }

  function animateCounter(el) {
    const target   = parseInt(el.dataset.counter, 10);
    const duration = 2000; // ms
    const step     = 16;   // ~60fps
    const steps    = duration / step;
    let current    = 0;

    const timer = setInterval(() => {
      current += target / steps;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      el.textContent = Math.floor(current) + (el.dataset.suffix || '');
    }, step);
  }

})();
