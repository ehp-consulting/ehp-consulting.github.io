/**
 * EHP — Environmental & Hospitality Partners
 * Main JavaScript: Navigation, Scroll Animations, Form Validation, Interactions
 *
 * Architecture:
 *  1. DOMContentLoaded init
 *  2. Navigation (sticky + mobile)
 *  3. Scroll reveal (IntersectionObserver)
 *  4. Parallax hero
 *  5. Counter animations
 *  6. Smooth scroll
 *  7. Contact form validation
 *  8. Mobile link behavior
 */

'use strict';

/* ─────────────────────────────────────────
   UTILITY HELPERS
───────────────────────────────────────── */

/**
 * Safely query a single DOM element.
 * @param {string} selector
 * @param {Element} [scope=document]
 * @returns {Element|null}
 */
const $ = (selector, scope = document) => scope.querySelector(selector);

/**
 * Safely query multiple DOM elements.
 * @param {string} selector
 * @param {Element} [scope=document]
 * @returns {NodeList}
 */
const $$ = (selector, scope = document) => scope.querySelectorAll(selector);

/**
 * Throttle a function to prevent too-frequent calls.
 * Useful for scroll/resize handlers.
 */
function throttle(fn, delay = 100) {
  let timer = null;
  return function (...args) {
    if (timer) return;
    timer = setTimeout(() => {
      fn.apply(this, args);
      timer = null;
    }, delay);
  };
}


/* ─────────────────────────────────────────
   1. NAVIGATION — Sticky state + mobile menu
───────────────────────────────────────── */
function initNavigation() {
  const nav         = $('#nav');
  const menuToggle  = $('#menuToggle');
  const mobileNav   = $('#mobileNav');
  const mobileClose = $('#mobileClose');
  const mobileLinks = $$('.mobile-link');

  if (!nav) return;

  // Sticky nav: adds .scrolled class after 80px scroll
  const handleNavScroll = throttle(() => {
    if (window.scrollY > 80) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  }, 50);

  window.addEventListener('scroll', handleNavScroll, { passive: true });

  // Initial check in case page loads mid-scroll
  handleNavScroll();

  // Mobile menu open/close
  function openMobileMenu() {
    mobileNav.classList.add('open');
    menuToggle.classList.add('open');
    menuToggle.setAttribute('aria-expanded', 'true');
    mobileNav.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden'; // Prevent background scroll
  }

  function closeMobileMenu() {
    mobileNav.classList.remove('open');
    menuToggle.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    mobileNav.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = ''; // Restore scroll
  }

  if (menuToggle) {
    menuToggle.addEventListener('click', () => {
      const isOpen = mobileNav.classList.contains('open');
      isOpen ? closeMobileMenu() : openMobileMenu();
    });
  }

  if (mobileClose) {
    mobileClose.addEventListener('click', closeMobileMenu);
  }

  // Close menu when a nav link is clicked
  mobileLinks.forEach(link => {
    link.addEventListener('click', closeMobileMenu);
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mobileNav.classList.contains('open')) {
      closeMobileMenu();
    }
  });
}


/* ─────────────────────────────────────────
   2. SCROLL REVEAL — IntersectionObserver
   Elements with class .reveal will fade in
   as they enter the viewport.
───────────────────────────────────────── */
function initScrollReveal() {
  // Respect prefers-reduced-motion: skip animation for accessibility
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (prefersReducedMotion) {
    // Immediately show all elements without animation
    $$('.reveal').forEach(el => el.classList.add('revealed'));
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          // Once revealed, stop observing to save resources
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.12,      // 12% of element must be visible
      rootMargin: '0px 0px -40px 0px' // Slightly before hitting viewport bottom
    }
  );

  $$('.reveal').forEach(el => observer.observe(el));
}


/* ─────────────────────────────────────────
   3. HERO PARALLAX — Subtle depth effect
   The hero background image moves at a
   slower rate than the scroll to create
   a sense of visual depth.
───────────────────────────────────────── */
function initParallax() {
  const heroBg = $('#heroBg');
  if (!heroBg) return;

  // Only run on devices that can handle it (skip mobile for performance)
  const isMobile = window.matchMedia('(max-width: 768px)').matches;
  if (isMobile) return;

  const handleParallax = throttle(() => {
    const scrollY = window.scrollY;
    // Move background at 30% of scroll speed for subtle depth
    heroBg.style.transform = `scale(1.05) translateY(${scrollY * 0.3}px)`;
  }, 16); // ~60fps throttle

  window.addEventListener('scroll', handleParallax, { passive: true });
}


/* ─────────────────────────────────────────
   4. COUNTER ANIMATION
   Numbers with data-target attribute animate
   from 0 to their target value when they
   enter the viewport.
───────────────────────────────────────── */
function initCounters() {
  const counters = $$('[data-target]');
  if (!counters.length) return;

  /**
   * Animate a number from 0 to target over duration ms.
   * Uses requestAnimationFrame for smooth, performant animation.
   */
  function animateCounter(element, target, duration = 1800) {
    const start = performance.now();
    const startVal = 0;

    function step(timestamp) {
      const elapsed = timestamp - start;
      const progress = Math.min(elapsed / duration, 1);

      // Ease out cubic: starts fast, slows to finish
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(startVal + (target - startVal) * eased);

      element.textContent = '+' + current.toLocaleString();

      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        element.textContent = '+' + target.toLocaleString();
      }
    }

    requestAnimationFrame(step);
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const target = parseInt(entry.target.dataset.target, 10);
          animateCounter(entry.target, target);
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.5 }
  );

  counters.forEach(counter => observer.observe(counter));
}


/* ─────────────────────────────────────────
   5. SMOOTH SCROLL
   All anchor links (href="#...") will scroll
   smoothly to their target, accounting for
   the sticky nav height.
───────────────────────────────────────── */
function initSmoothScroll() {
  $$('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href === '#') return; // Skip pure hash links

      const target = document.getElementById(href.substring(1));
      if (!target) return;

      e.preventDefault();

      const navHeight = 80; // Account for sticky nav
      const targetPosition = target.getBoundingClientRect().top + window.scrollY - navHeight;

      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    });
  });
}


/* ─────────────────────────────────────────
   6. CONTACT FORM VALIDATION
   Client-side validation with accessible
   error messaging and success state.
───────────────────────────────────────── */
function initContactForm() {
  const form       = $('#contactForm');
  const successMsg = $('#formSuccess');
  const submitBtn  = $('#submitBtn');

  if (!form) return;

  /**
   * Validate a single field and display/clear error state.
   * Returns true if valid, false if not.
   */
  function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    let errorMsg = '';

    if (field.required && !value) {
      isValid = false;
      errorMsg = 'Este campo es obligatorio.';
    } else if (field.type === 'email' && value) {
      // Basic RFC5322-inspired email check
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(value)) {
        isValid = false;
        errorMsg = 'Por favor ingrese un correo electrónico válido.';
      }
    }

    // Visual feedback: red border on error
    if (!isValid) {
      field.style.borderColor = 'rgba(220, 80, 80, 0.5)';

      // Create or update error message element
      let errorEl = field.parentElement.querySelector('.field-error');
      if (!errorEl) {
        errorEl = document.createElement('span');
        errorEl.className = 'field-error';
        errorEl.style.cssText = `
          display: block;
          font-size: 0.6875rem;
          color: #E05050;
          margin-top: 0.375rem;
          letter-spacing: 0.02em;
        `;
        field.parentElement.appendChild(errorEl);
      }
      errorEl.textContent = errorMsg;
    } else {
      field.style.borderColor = '';

      // Remove error message if present
      const errorEl = field.parentElement.querySelector('.field-error');
      if (errorEl) errorEl.remove();
    }

    return isValid;
  }

  // Live validation: validate as user types/blurs
  $$('input, select, textarea', form).forEach(field => {
    field.addEventListener('blur', () => validateField(field));
    field.addEventListener('input', () => {
      // Clear error on input (re-validate only on blur)
      field.style.borderColor = '';
      const errorEl = field.parentElement.querySelector('.field-error');
      if (errorEl) errorEl.remove();
    });
  });

  // Form submission
  form.addEventListener('submit', function (e) {
    e.preventDefault();

    // Validate all required fields
    const requiredFields = $$('[required]', form);
    let isFormValid = true;

    requiredFields.forEach(field => {
      if (!validateField(field)) {
        isFormValid = false;
      }
    });

    if (!isFormValid) {
      // Scroll to first invalid field
      const firstError = form.querySelector('[style*="borderColor"]');
      if (firstError) {
        firstError.focus();
        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }

    // Simulate form submission (replace with actual fetch/API call)
    submitBtn.disabled = true;
    submitBtn.textContent = 'Enviando...';

    setTimeout(() => {
      // Success state
      form.style.display = 'none';

      if (successMsg) {
        successMsg.style.display = 'block';
        successMsg.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }

      // In production, replace the setTimeout above with:
      /*
      fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.fromEntries(new FormData(form)))
      })
      .then(res => res.json())
      .then(data => { ... handle success ... })
      .catch(err => { ... handle error ... });
      */
    }, 1000);
  });
}


/* ─────────────────────────────────────────
   7. ACTIVE NAV LINKS
   Highlights the active section in the
   navigation as user scrolls through the page.
───────────────────────────────────────── */
function initActiveNavLinks() {
  const navLinks = $$('.nav__links a[href^="#"]');
  if (!navLinks.length) return;

  // Collect all section targets
  const sections = Array.from(navLinks)
    .map(link => document.getElementById(link.getAttribute('href').substring(1)))
    .filter(Boolean);

  const handleActiveLink = throttle(() => {
    const scrollPos = window.scrollY + 150; // Offset for nav height

    let activeSection = null;

    sections.forEach(section => {
      if (section.offsetTop <= scrollPos) {
        activeSection = section;
      }
    });

    navLinks.forEach(link => {
      link.style.color = '';
    });

    if (activeSection) {
      const activeLink = $(`a[href="#${activeSection.id}"]`, document.querySelector('.nav__links'));
      if (activeLink) {
        activeLink.style.color = 'var(--gold)';
      }
    }
  }, 100);

  window.addEventListener('scroll', handleActiveLink, { passive: true });
}


/* ─────────────────────────────────────────
   8. HOVER DEPTH EFFECTS
   Subtle card tilt effect on hover for
   certain card types (mouse tracking).
   Only applied on non-touch devices.
───────────────────────────────────────── */
function initCardTilt() {
  // Only on desktop with pointer support
  if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;

  const cards = $$('.case-card, .cert-card');

  cards.forEach(card => {
    card.addEventListener('mousemove', function (e) {
      const rect = this.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const deltaX = (e.clientX - centerX) / (rect.width / 2);
      const deltaY = (e.clientY - centerY) / (rect.height / 2);

      // Very subtle tilt: max 3 degrees
      const tiltX = deltaY * -2;
      const tiltY = deltaX * 2;

      this.style.transform = `perspective(800px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) translateY(-6px)`;
      this.style.transition = 'transform 0.1s ease';
    });

    card.addEventListener('mouseleave', function () {
      this.style.transform = '';
      this.style.transition = 'transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)';
    });
  });
}


/* ─────────────────────────────────────────
   9. PILLAR CARD TABS / TOGGLE
   On mobile, pillar cards can be expanded/
   collapsed for better readability.
───────────────────────────────────────── */
function initPillarCards() {
  // Only activate on mobile sizes where cards are stacked
  if (window.innerWidth > 900) return;

  const cards = $$('.pillar-card');

  cards.forEach((card, index) => {
    const list = card.querySelector('.pillar-card__list');
    if (!list) return;

    // First card is expanded by default
    if (index !== 0) {
      list.style.maxHeight = '0';
      list.style.overflow = 'hidden';
      list.style.transition = 'max-height 0.4s ease';
    }

    // Make title clickable to toggle
    const title = card.querySelector('.pillar-card__title');
    if (!title) return;

    title.style.cursor = 'pointer';
    title.setAttribute('role', 'button');
    title.setAttribute('tabindex', '0');
    title.setAttribute('aria-expanded', index === 0 ? 'true' : 'false');

    const toggle = () => {
      const isOpen = list.style.maxHeight !== '0px' && list.style.maxHeight !== '';
      if (isOpen) {
        list.style.maxHeight = '0';
        title.setAttribute('aria-expanded', 'false');
      } else {
        list.style.maxHeight = list.scrollHeight + 'px';
        title.setAttribute('aria-expanded', 'true');
      }
    };

    title.addEventListener('click', toggle);
    title.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggle();
      }
    });
  });
}


/* ─────────────────────────────────────────
   INIT — Run everything on DOM ready
───────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {

  // Core interactions (always run)
  initNavigation();
  initSmoothScroll();
  initContactForm();

  // Scroll-based (check for IntersectionObserver support)
  if ('IntersectionObserver' in window) {
    initScrollReveal();
    initCounters();
    initActiveNavLinks();
  } else {
    // Fallback: show all elements immediately for older browsers
    $$('.reveal').forEach(el => el.classList.add('revealed'));
  }

  // Enhancement (progressive)
  initParallax();
  initCardTilt();
  initPillarCards();

  // Log confirmation in development
  // console.log('EHP Website — All modules initialized.');
});


/* ─────────────────────────────────────────
   RESIZE HANDLER
   Re-initialize components that depend on
   viewport size when window is resized.
───────────────────────────────────────── */
let resizeTimer;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    // Re-check pillar card collapse behavior
    initPillarCards();
  }, 250);
});
